package ADT.example.constants;

/**
 * @author inexture
 */
public class ADTPortletKeys {

	public static final String ADT = "ADT";
	public static final String ADT1 = "ADT1";

}